<!DOCTYPE html>
<!--		Author: 	
		Date:	    
		File:		mileage-array
		Purpose:	Mileage Array
-->
<html>
<head>
	<title>Mileage Array</title>
	<link rel ="stylesheet" type="text/css" href="mileage.css">
</head>
<body>
        <h1>MILEAGE ARRAY</h1>
        
        <?php
                $mileages = array(37, 61, 100, 12, 35, 119, 25, 69, 82, 127, 
                                  231, 62, 394, 100, 182, 21, 45, 255, 121, 87);
                                  
		$totalMiles = 0;
		$longTrips = 0;
		$longestTrip = 0;
		$shortestTrip = 0;

		// your code..
		
		
		print( "<p>Total Mileage: $totalMiles miles</p>
                        <p>Longest Trip: $longestTrip miles</p>
                        <p>Shortest Trip: $shortestTrip miles</p>
                        <p>Number of long trips (100 miles or more): $longTrips</p>");
		
                print("<p><a href = \"mileage-home.html\">Home</a></p>");
	?>
</body>
</html>
