<!DOCTYPE html>
<!--		Author: 	
		Date:	        
		File:		mileage-chart.php
		Purpose:	Mileage Chart
-->
<html>
<head>
	<title>Mileage Chart</title>
	<link rel ="stylesheet" type="text/css" href="mileage.css">
</head>
<body>
    <h1>Mileage Chart</h1>
    <?php 
        print("<table border = \"1\">");

        // your code..
        
        print("</table>");
        print("<p>Return to <a href = \"mileage-home.html\">Home</a></p>");
    ?>
</body>
</html>
