<!DOCTYPE html>
<!--		Author: 	
		Date:	    
		File:		mileage-function
		Purpose:	Mileage Function
-->
<html>
<head>
	<title>Mileage Function</title>
	<link rel ="stylesheet" type="text/css" href="mileage.css">
</head>
<body>
        <h1>MILEAGE FUNCTION</h1>
        <?php
             
                $miles = $_POST['miles'];

                // your code..
                
		print( "<p>Your reimbursement for $miles miles travelled is $". 
                        number_format($amount, 2).".</p>");
		
                print("<p><a href = \"mileage-home.html\">Home</a></p>");
	?>
</body>
</html>
