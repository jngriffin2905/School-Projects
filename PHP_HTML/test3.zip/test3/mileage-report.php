<!DOCTYPE html>
<!--		Author: 	
		Date:	    
		File:		mileage-report
		Purpose:	Mileage Report
-->
<html>
<head>
	<title>Mileage Report</title>
	<link rel ="stylesheet" type="text/css" href="mileage.css">
</head>
<body>
        <h1>MILEAGE REPORT</h1>
        <?php
                $totalTrips = 0;
                $totalMileage = 0;
                $noTravelMonths = 0;
                
                $logFile =fopen("trip-record.txt","r");

                // your code..
                
                
                
                fclose($logFile );
		
		print( "<p>Total Mileage: $totalMileage miles</p>
                        <p>Total Number of trips: $totalTrips</p>
                        <p>Number of months with no travel: $noTravelMonths</p>");
		
                print("<p><a href = \"mileage-home.html\">Home</a></p>");
	?>
</body>
</html>
